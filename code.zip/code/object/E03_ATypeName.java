//: object/E03_ATypeName.java
/****************** Exercise 3 ******************
 * Turn the code fragments involving ATypeName
 * into a program that compiles and
 * runs.
 ************************************************/
package object;

public class E03_ATypeName {
  public static void main(String[] args) {
    E03_ATypeName a = new E03_ATypeName();
  }
} ///:~
