//: object/E04_DataOnly.java
/****************** Exercise 4 ******************
 * Turn the DataOnly code fragments into a
 * program that compiles and runs.
 ************************************************/
package object;

public class E04_DataOnly {
  int i;
  double d;
  boolean b;
  public static void main(String[] args) {
    E04_DataOnly d = new E04_DataOnly();
    d.i = 47;
    d.d = 1.1;
    d.b = false;
  }
} ///:~
