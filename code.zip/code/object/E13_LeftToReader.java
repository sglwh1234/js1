//: object/E13_LeftToReader.java
/****************** Exercise 13 *****************
 * Run Documentation1.java, Documentation2.java,
 * and Documentation3.java through Javadoc. Verify
 * the resulting documentation with your Web
 * browser.
 ************************************************/
package object;

public class E13_LeftToReader {
  public static void main(String args[]) {
    System.out.println("Exercise left to reader");
  }
} ///:~
