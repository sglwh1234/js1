//: net/mindview/util/Null.java
package net.mindview.util;
public interface Null {} ///:~
